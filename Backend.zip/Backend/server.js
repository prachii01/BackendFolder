const express=require('express');
const fs = require('fs');
let students = require('./students.json');

const app = express();
console.log(students);
app.use(express.json()); 


app.get('/students',(req,res)=>{
    res.send(students);
})

app.get('/students/:roll_no',(req,res)=> {
    const RollNo = req.params.roll_no;
    for(const stud of students){
        if(stud.roll_no===RollNo){
            res.send(stud);
        }
    }
})

app.post('/students',(req,res)=>{
    const newData=req.body;
    students.push(newData);
    fs.writeFileSync('./students.json',JSON.stringify(students));
    res.send("Data added successfully!!");
})

app.delete('/students/:roll_no', (req, res) => {
    const RollNo = req.params.roll_no;
    const existingStudent = students.find((stu) => stu.roll_no == RollNo);
    if (!existingStudent) {
        res.status(404).send('Data not found');
        return;
    }
    const newOp = students.filter((stu) => stu.roll_no != RollNo);
    students = newOp;
    console.log({ newOp });
    fs.writeFileSync('./students.json', JSON.stringify(newOp));
    res.send('Data deleted successfully !!');
});

app.put('/students/:roll_no', (req, res) => {
    const RollNo = req.params.roll_no;
    const updatedData = req.body;
    const index = students.findIndex((stu) => stu.roll_no === RollNo);

    if (index !== -1) {
        students[index] = { ...students[index], ...updatedData };

        fs.writeFileSync('./students.json', JSON.stringify(students));
        res.send('Data updated successfully !!');
    } else {
        res.status(404).send('Student not found');
    }
});

app.listen(3000, ()=> console.log("http://localhost:3000"));