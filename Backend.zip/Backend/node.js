const fs=require('fs')
//const data=fs.readFileSync('./hello.txt','utf8');
//console.log(data); // by default adta reads in bytes form to change it specify encoding (UTF) read file sync(sunchronous)
// now start asynchronous version
/*fs.readFile('./hello.txt','utf8',(err,data)=> {
    console.log("ERROR: ");
    console.log(err);
    console.log("DATA: ");
    console.log(data);
    /*fs.readFile('./hello2.txt','utf8',(err,data)=>{
        console.log(data);
        fs.readFile('./hello3.txt','utf8')
    })*/
//}) // yeh code ko block nhi krega saath saath chalta rhega
// if you dont want to use callbacks you can use promises
fs.promises.readFile("./hello.txt",'utf8')
.then((data)=> {console.log(data);}) // if succesfful
.catch((err)=> {console.log(err);}) // if error
